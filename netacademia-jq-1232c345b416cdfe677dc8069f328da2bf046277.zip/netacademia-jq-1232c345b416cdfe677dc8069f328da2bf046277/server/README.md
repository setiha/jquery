# Server telepítés lokális gépre
- Node.js telepítése: https://nodejs.org/en/download/  LTS verzióból 64 bit-est kell letölteni és telepíteni
- npm install (server könyvtár alatt egy cmd-ben kell kiadni a parancsot)

# Server indítása
- npm run start (server könyvtár alatt egy cmd-ben kell kiadni a parancsot)
- vagy windows felhasználók esetén a runserver.bat -t kell elindítani

# Külső eszköz dokumentációk
- https://github.com/typicode/json-server

